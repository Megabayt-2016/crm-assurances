<?php echo e($slot); ?>

<?php /**PATH E:\Wamp64\www\CrmApp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>