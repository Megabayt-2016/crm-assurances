<!DOCTYPE html>
<html>
<head>
    <title>CCA</title>
</head>
<body>
    <h1>CARREZ CONSEIL ASSURANCES</h1>
    <p><?php echo e($data['message']); ?></p>
     
    <p>Merci pour votre confiance</p>
    <img src="<?php echo e(asset('../img/favicon-32x32.png')); ?>" >

</body>
</html><?php /**PATH E:\Wamp64\www\CrmApp\resources\views/emails/myTestMail.blade.php ENDPATH**/ ?>