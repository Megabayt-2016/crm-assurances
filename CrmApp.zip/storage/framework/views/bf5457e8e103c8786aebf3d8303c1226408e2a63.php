<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>This is test mail</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container text-center m-1">
        <h1 class="lead mt-3">Send mail using attachment</h1>
        <p class="lead"><?php echo e($mail->message); ?></p>
        <p class="lead"></p>
    </div>
</body>
</html><?php /**PATH E:\Wamp64\www\CrmApp\resources\views/mail.blade.php ENDPATH**/ ?>