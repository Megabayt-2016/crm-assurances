<?php
trait Ex2
{
    public static  $cmpt=0;

    public function incremente()
    {
        self::$cmpt++;
    }
    public function decremente()
    {
        self::$cmpt--;
    }
}

class Visiteur
{
    use Ex2;
    public function nombreVisits()
    {
        echo self::$cmpt;
    }
}

$v=new Visiteur();
for ($i=0; $i < 5; $i++) { 
    $v->incremente();
}
$v->nombreVisits();
?>