<!DOCTYPE html>
<html>
<head>
    <title>CCA</title>
</head>
<body>
    <h1>CARREZ CONSEIL ASSURANCES</h1>
    <p>{{$data['message']}}</p>
     
    <p>Merci pour votre confiance</p>
    <img src="{{ asset('../img/favicon-144x144.png')}} " >

</body>
</html>